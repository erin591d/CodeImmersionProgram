﻿using System;

namespace Calculator
{
    public class CalculatorApp
    {
        ///Add your code for application here
        ///Write a method for Subtraction, Multiplication, Division
        
        public int Add(int a, int b)
        {
            return a + b;
        }


    }
}
